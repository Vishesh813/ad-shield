(() => {
  if (window.__ADSHIELD_POPUP__) return;
  let win = window;
  let doc;
  try { doc = win.document; } catch { return; }
  win.__ADSHIELD_POPUP__ = true;

  let enabled = false;
  const realOpen = win.open ? win.open.bind(win) : null;
  let lastGesture = 0;

  const gestureEvents = ["pointerdown", "pointerup", "mousedown", "keydown", "touchstart"];
  const onGesture = () => { lastGesture = performance.now(); };
  for (const ev of gestureEvents) win.addEventListener(ev, onGesture, { capture: true, passive: true });

  function readConfig() {
    try {
      enabled = !!(doc.documentElement && doc.documentElement.getAttribute("data-sh-popup") === "1");
    } catch { enabled = false; }
  }
  readConfig();
  try {
    new MutationObserver(() => readConfig()).observe(doc.documentElement, { attributes: true, attributeFilter: ["data-sh-popup"] });
  } catch {}

  function hasGesture() {
    const now = performance.now();
    if (now - lastGesture < 3000) return true;
    try { if (navigator.userActivation && navigator.userActivation.isActive) return true; } catch {}
    return false;
  }

  function makeNop(closed) {
    const target = {
      close() { target.closed = true; },
      focus() {},
      blur() {},
      postMessage() {},
      document: null,
      location: null,
      width: 0,
      height: 0
    };
    target.closed = !!closed;
    return target;
  }

  function notify(type) {
    try { win.postMessage({ __adshield: true, type }, "*"); } catch {}
  }

  let openCount = 0;
  let openCountSince = 0;

  win.open = function open(urlArg, nameArg, featuresArg) {
    readConfig();
    if (!enabled) return realOpen ? realOpen.apply(this, arguments) : null;

    if (!hasGesture()) {
      notify("popupBlocked");
      return makeNop(true);
    }

    const now = performance.now();
    if (now - openCountSince > 900) { openCount = 0; openCountSince = now; }
    openCount += 1;
    if (openCount > 1) {
      notify("popupBlocked");
      return makeNop(true);
    }

    const cleanUrl = typeof urlArg === "string" ? urlArg.trim() : "";
    if (cleanUrl === "" || cleanUrl === "about:blank") {
      notify("popupBlocked");
      return makeNop(true);
    }

    return realOpen ? realOpen.apply(this, arguments) : null;
  };
})();