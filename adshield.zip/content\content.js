const COSMETIC_SELECTORS = [
  "ins.adsbygoogle",
  "[data-adsbygoogle-status]",
  "[data-ad-client]",
  "[data-ad-slot]",
  "[data-ad-format]",
  ".adsbygoogle",
  ".advertisement",
  ".ad-container",
  ".ad-slot",
  ".ad-unit",
  ".ad-box",
  ".ad-banner",
  ".ad-inline",
  ".ad-leaderboard",
  ".ad-skin",
  ".ad-sticky",
  ".ad-wrapper",
  ".google-ad",
  ".sponsored-content",
  ".sponsoredArticle",
  "#ad-banner",
  "#ad-sidebar",
  "#ads-block",
  "#adholder",
  "#ad-slot",
  "#ads-box",
  "#adspace",
  ".advert",
  ".advertisment",
  ".adv-top",
  ".ad_wrap",
  ".ad-wrap",
  ".ad_popup",
  ".ad_popunder",
  "[class*='ad-slot']",
  "[class*='ad-container']",
  "[class*='ad-banner']",
  "[class*='advertisement']",
  "[class*='sponsored-']",
  ".sponsored-goods",
  ".promo-ad",
  ".product-ad"
];

const IFRAME_PATTERNS = [
  /(googlesyndication|doubleclick|googleadservices|taboola|outbrain|revcontent|criteo|mgid\.com)/i,
  /(^|\/)(ads|advert|sponsored)(\/|\.|\?|$)/i
];

class AdShieldContent {
  constructor() {
    this.host = (location.hostname || "").toLowerCase();
    this.state = { enabled: true, blockAds: true, blockTrackers: true, blockPopups: true, stealthMode: false, allowList: [] };
    this.active = false;
    this.style = null;
    this.observer = null;
    this.mutationTimer = null;
    this.pendingCount = 0;
    this.countTimer = null;
    this.payloadInjected = false;
    this.listening = false;
  }

  async boot() {
    this.setPopupFlag(true);
    this.injectPayload();
    window.addEventListener("pageshow", () => {
      this.fetchState();
      if (this.active) this.scanDocument();
    });
    window.addEventListener("pagehide", () => {
      if (this.countTimer) {
        clearTimeout(this.countTimer);
        this.countTimer = null;
      }
    });
    await this.fetchState();
    this.listenStorage();
  }

  listenStorage() {
    if (this.listening) return;
    this.listening = true;
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "shSettingsChanged") this.fetchState();
    });
    window.addEventListener("message", (e) => {
      if (!e.data || e.data.__adshield !== true) return;
      if (e.data.type === "popupBlocked") {
        chrome.runtime.sendMessage({ type: "blockCount", kind: "popup" }).catch(() => {});
      }
    });
  }

  async fetchState() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "getState" }, (resp) => {
        if (resp && resp.ok) this.state = resp.state;
        this.apply();
        resolve();
      });
    });
  }

  apply() {
    const allow = (this.state.allowList || []).some((h) => h === this.host);
    this.active = this.state.enabled && this.state.blockAds && !allow;
    this.setPopupFlag(this.state.enabled && this.state.blockPopups && !allow);
    if (this.active) this.ensureHiding();
    else this.teardownHiding();
  }

  setPopupFlag(enabled) {
    const root = document.documentElement;
    if (!root) return;
    root.setAttribute("data-sh-popup", enabled ? "1" : "0");
  }

  ensureHiding() {
    if (!this.style || !this.style.parentNode) {
      const style = document.createElement("style");
      style.setAttribute("data-sh-ss", "1");
      (document.head || document.documentElement).appendChild(style);
      this.style = style;
      const sheet = style.sheet;
      for (const sel of COSMETIC_SELECTORS) {
        try {
          const rule = this.state.stealthMode
            ? `${sel} { visibility: hidden !important; height: 0 !important; max-height: 0 !important; overflow: hidden !important; }`
            : `${sel} { display: none !important; }`;
          sheet.insertRule(rule, sheet.cssRules.length);
        } catch {}
      }
    }
    if (!this.observer) {
      this.observer = new MutationObserver((muts) => {
        if (muts.some((m) => Array.from(m.addedNodes || []).some((n) => n.nodeType === 1))) {
          clearTimeout(this.mutationTimer);
          this.mutationTimer = setTimeout(() => this.scanDocument(), 40);
        }
      });
      this.observer.observe(document.documentElement, { childList: true, subtree: true });
    }
    this.scanDocument();
  }

  teardownHiding() {
    if (this.style) {
      this.style.remove();
      this.style = null;
    }
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
  }

  scanDocument() {
    if (!this.active) return;
    let count = 0;
    for (const sel of COSMETIC_SELECTORS) {
      let els;
      try {
        els = document.querySelectorAll(sel);
      } catch {
        continue;
      }
      for (const el of els) {
        if (el.hasAttribute("data-sh-hide")) continue;
        el.setAttribute("data-sh-hide", "1");
        this.hideElement(el);
        count++;
      }
    }
    for (const node of document.querySelectorAll("iframe, object, embed")) {
      const src = node.getAttribute("src") || node.getAttribute("data-src") || "";
      if (!src) continue;
      if (IFRAME_PATTERNS.some((re) => re.test(src)) && !node.hasAttribute("data-sh-hide")) {
        node.setAttribute("data-sh-hide", "1");
        this.hideElement(node);
        count++;
      }
    }
    if (count) this.reportCosmetic(count);
  }

  hideElement(el) {
    if (this.state.stealthMode) {
      const s = el.style;
      s.setProperty("visibility", "hidden", "important");
      s.setProperty("height", "0", "important");
      s.setProperty("max-height", "0", "important");
      s.setProperty("overflow", "hidden", "important");
    } else {
      const s = el.style;
      s.setProperty("display", "none", "important");
      s.setProperty("height", "0", "important");
      s.setProperty("margin", "0", "important");
      s.setProperty("padding", "0", "important");
    }
  }

  reportCosmetic(n) {
    this.pendingCount += n;
    if (this.countTimer) return;
    this.countTimer = setTimeout(() => {
      this.countTimer = null;
      if (!this.pendingCount) return;
      chrome.runtime.sendMessage({ type: "blockCount", kind: "cosmetic", n: this.pendingCount, host: this.host }).catch(() => {});
      this.pendingCount = 0;
    }, 2000);
  }

  injectPayload() {
    if (this.payloadInjected || !chrome.runtime || !chrome.runtime.getURL) return;
    this.payloadInjected = true;
    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("content/popup-payload.js");
      s.async = false;
      (document.head || document.documentElement).appendChild(s);
    } catch {}
  }
}

new AdShieldContent().boot();